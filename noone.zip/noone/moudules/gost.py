#! /usr/bin/env python2.7
import time
import datetime
from termcolor import colored, cprint

def GostIndex():
    cprint("         \033[92m[  \033[96mNo_One v1 \033[91m(Web application Scanner) \033[92m]", 'red')
    time.sleep(0.1)
    cprint("         \033[92m[  \033[96mMHM: \033[91mbest-Security \033[92m]", 'red')
    time.sleep(0.5)
    print("         \033[92m[  \033[96mModules available : \033[91m4 \033[92m] ")
    print "\n"
    print("\033[96mFor command type \033[91m'help'")
